"""
Secret Scanner Utility

This module provides functionality to scan for potential secrets, API keys,
and sensitive information in code repositories.
"""

import logging
import os
import re
from typing import List, Dict, Optional, Any, Pattern
from dataclasses import dataclass

logger = logging.getLogger(__name__)


@dataclass
class SecretMatch:
    """Represents a potential secret found in code"""

    type: str
    file_path: str
    line_number: int
    line_content: str
    matched_text: str
    confidence: float
    severity: str = "medium"


class SecretScanner:
    """
    Scanner for detecting potential secrets and sensitive information in code
    """

    def __init__(self):
        """Initialize the secret scanner with predefined patterns"""
        self.patterns: Dict[str, Pattern[str]] = self._compile_patterns()
        self.excluded_extensions = {
            ".jpg",
            ".png",
            ".gif",
            ".pdf",
            ".zip",
            ".tar",
            ".gz",
        }
        self.excluded_directories = {
            "node_modules",
            ".git",
            "__pycache__",
            "venv",
            ".env",
        }

    def _compile_patterns(self) -> Dict[str, Pattern[str]]:
        """Compile regex patterns for different types of secrets"""
        patterns = {
            # API Keys
            "api_key": re.compile(
                r'(?i)(api[_-]?key|apikey)[\'"\s]*[:=][\'"\s]*([a-zA-Z0-9_-]{20,})',
                re.MULTILINE,
            ),
            "secret_key": re.compile(
                r'(?i)(secret[_-]?key|secretkey)[\'"\s]*[:=][\'"\s]*([a-zA-Z0-9_-]{20,})',
                re.MULTILINE,
            ),
            # Database URLs
            "database_url": re.compile(
                r'(?i)(database[_-]?url|db[_-]?url)[\'"\s]*[:=][\'"\s]*([^\'"\s]+)',
                re.MULTILINE,
            ),
            "connection_string": re.compile(
                r'(?i)(connection[_-]?string)[\'"\s]*[:=][\'"\s]*([^\'"\s]+)',
                re.MULTILINE,
            ),
            # Authentication tokens
            "jwt_token": re.compile(
                r"eyJ[A-Za-z0-9_-]*\.[A-Za-z0-9_-]*\.[A-Za-z0-9_-]*", re.MULTILINE
            ),
            "bearer_token": re.compile(r"(?i)bearer\s+([A-Za-z0-9_-]+)", re.MULTILINE),
            # Cloud service keys
            "aws_access_key": re.compile(r"AKIA[0-9A-Z]{16}", re.MULTILINE),
            "aws_secret_key": re.compile(
                r'(?i)(aws[_-]?secret[_-]?access[_-]?key)[\'"\s]*[:=][\'"\s]*([A-Za-z0-9/+=]{40})',
                re.MULTILINE,
            ),
            # Generic passwords
            "password": re.compile(
                r'(?i)(password|passwd|pwd)[\'"\s]*[:=][\'"\s]*([^\'"\s]{8,})',
                re.MULTILINE,
            ),
            # Email addresses (lower severity)
            "email": re.compile(
                r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b", re.MULTILINE
            ),
            # Private keys
            "private_key": re.compile(
                r"-----BEGIN[A-Z\s]+PRIVATE KEY-----", re.MULTILINE
            ),
        }

        return patterns

    def scan_content(self, content: str, file_path: str = "") -> List[SecretMatch]:
        """
        Scan content for potential secrets

        Args:
            content: Text content to scan
            file_path: Path of the file being scanned

        Returns:
            List of potential secret matches
        """
        matches: List[SecretMatch] = []

        if not content or not content.strip():
            return matches

        lines = content.split("\n")

        for pattern_name, pattern in self.patterns.items():
            for match in pattern.finditer(content):
                # Find line number
                line_number = content[: match.start()].count("\n") + 1
                line_content = (
                    lines[line_number - 1] if line_number <= len(lines) else ""
                )

                # Calculate confidence based on pattern type and context
                confidence = self._calculate_confidence(
                    pattern_name, match.group(), line_content
                )

                # Determine severity
                severity = self._determine_severity(pattern_name, confidence)

                secret_match = SecretMatch(
                    type=pattern_name,
                    file_path=file_path,
                    line_number=line_number,
                    line_content=line_content.strip(),
                    matched_text=match.group(),
                    confidence=confidence,
                    severity=severity,
                )

                matches.append(secret_match)

        return matches

    def _calculate_confidence(
        self, pattern_type: str, matched_text: str, line_content: str
    ) -> float:
        """Calculate confidence score for a potential secret match"""
        base_confidence = 0.5

        # Pattern-specific confidence adjustments
        confidence_adjustments = {
            "jwt_token": 0.9,
            "aws_access_key": 0.95,
            "private_key": 0.95,
            "email": 0.3,  # Lower confidence for emails
            "password": 0.6,
        }

        confidence = confidence_adjustments.get(pattern_type, base_confidence)

        # Context-based adjustments
        lower_line = line_content.lower()

        # Reduce confidence for common false positives
        if any(
            word in lower_line
            for word in ["example", "test", "demo", "placeholder", "todo", "fixme"]
        ):
            confidence *= 0.3

        # Reduce confidence for obvious fake values
        if any(
            fake in matched_text.lower()
            for fake in ["fake", "dummy", "test", "example"]
        ):
            confidence *= 0.2

        # Increase confidence for production-like contexts
        if any(word in lower_line for word in ["prod", "production", "live", "deploy"]):
            confidence *= 1.5

        return min(confidence, 1.0)

    def _determine_severity(self, pattern_type: str, confidence: float) -> str:
        """Determine severity level based on pattern type and confidence"""
        high_severity_patterns = {
            "aws_access_key",
            "aws_secret_key",
            "private_key",
            "jwt_token",
        }
        medium_severity_patterns = {
            "api_key",
            "secret_key",
            "database_url",
            "connection_string",
            "password",
        }

        if pattern_type in high_severity_patterns and confidence > 0.7:
            return "high"
        elif pattern_type in medium_severity_patterns and confidence > 0.5:
            return "medium"
        else:
            return "low"

    def scan_file(self, file_path: str) -> List[SecretMatch]:
        """
        Scan a single file for secrets

        Args:
            file_path: Path to the file to scan

        Returns:
            List of potential secret matches
        """
        try:
            if not os.path.exists(file_path):
                logger.warning(f"File not found: {file_path}")
                return []

            # Skip binary files and excluded extensions
            file_ext = os.path.splitext(file_path)[1].lower()
            if file_ext in self.excluded_extensions:
                return []

            with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
                content = f.read()

            return self.scan_content(content, file_path)

        except Exception as e:
            logger.error(f"Error scanning file {file_path}: {e}")
            return []

    def scan_directory(
        self, directory_path: str, max_files: int = 1000
    ) -> List[SecretMatch]:
        """
        Recursively scan directory for secrets

        Args:
            directory_path: Path to directory to scan
            max_files: Maximum number of files to scan

        Returns:
            List of all potential secret matches found
        """
        all_matches: List[SecretMatch] = []
        files_scanned = 0

        try:
            for root, dirs, files in os.walk(directory_path):
                # Skip excluded directories
                dirs[:] = [d for d in dirs if d not in self.excluded_directories]

                for file in files:
                    if files_scanned >= max_files:
                        logger.warning(f"Reached maximum file limit ({max_files})")
                        break

                    file_path = os.path.join(root, file)
                    matches = self.scan_file(file_path)
                    all_matches.extend(matches)
                    files_scanned += 1

                if files_scanned >= max_files:
                    break

        except Exception as e:
            logger.error(f"Error scanning directory {directory_path}: {e}")

        logger.info(
            f"Scanned {files_scanned} files, found {len(all_matches)} potential secrets"
        )
        return all_matches

    def get_summary(self, matches: List[SecretMatch]) -> Dict[str, Any]:
        """
        Generate summary statistics for secret matches

        Args:
            matches: List of secret matches

        Returns:
            Dictionary containing summary statistics
        """
        if not matches:
            return {
                "total_matches": 0,
                "by_severity": {"high": 0, "medium": 0, "low": 0},
                "by_type": {},
                "unique_files": 0,
            }

        by_severity = {"high": 0, "medium": 0, "low": 0}
        by_type: Dict[str, int] = {}
        unique_files = set()

        for match in matches:
            by_severity[match.severity] += 1
            by_type[match.type] = by_type.get(match.type, 0) + 1
            unique_files.add(match.file_path)

        return {
            "total_matches": len(matches),
            "by_severity": by_severity,
            "by_type": by_type,
            "unique_files": len(unique_files),
            "high_confidence_matches": len([m for m in matches if m.confidence > 0.8]),
        }


def create_secret_scanner() -> SecretScanner:
    """
    Factory function to create a SecretScanner instance

    Returns:
        Configured SecretScanner instance
    """
    logger.info("Creating secret scanner instance")
    return SecretScanner()


# Convenience functions for direct usage
def scan_content_for_secrets(content: str, file_path: str = "") -> List[SecretMatch]:
    """Convenience function to scan content for secrets"""
    scanner = create_secret_scanner()
    return scanner.scan_content(content, file_path)


def scan_file_for_secrets(file_path: str) -> List[SecretMatch]:
    """Convenience function to scan a file for secrets"""
    scanner = create_secret_scanner()
    return scanner.scan_file(file_path)


def scan_directory_for_secrets(
    directory_path: str, max_files: int = 1000
) -> List[SecretMatch]:
    """Convenience function to scan a directory for secrets"""
    scanner = create_secret_scanner()
    return scanner.scan_directory(directory_path, max_files)
